#!/bin/bash
dir_base=../dataset

mkdir -p "$dir_base"/safe_bytecode
mkdir -p "$dir_base"/unsafe_bytecode

# loop through and compile safe samples
for f in "$dir_base"/safe_generated/*.c; do
  file_name=$(basename "$f" .c)
  clang -O0 -target bpf -c "$f" -o "$dir_base"/safe_bytecode/"$file_name".o
done

# loop through and compile unsafe samples
for f in "$dir_base"/unsafe_generated/*.c; do
  file_name=$(basename "$f" .c)
  clang -O0 -target bpf -c "$f" -o "$dir_base"/unsafe_bytecode/"$file_name".o
done

