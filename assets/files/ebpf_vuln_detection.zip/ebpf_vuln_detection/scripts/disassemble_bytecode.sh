#!/bin/bash
base_dir=../dataset

# loop through and disassemble safe bytecode
for file in $base_dir/safe_bytecode/*.o; do
    file_name=$(basename "$file" .o)
    llvm-objdump -d "$file" > "$base_dir/safe_disasm/$file_name.disasm"
done

# loop through and disassemble unsafe bytecode
for file in $base_dir/unsafe_bytecode/*.o; do
    file_name=$(basename "$file" .o)
    llvm-objdump -d "$file" > "$base_dir/unsafe_disasm/$file_name.disasm"
done

