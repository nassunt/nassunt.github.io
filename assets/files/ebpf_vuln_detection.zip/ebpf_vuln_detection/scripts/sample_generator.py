import random
from pathlib import Path

out_dir = Path("../dataset")
safe_dir = out_dir / "safe_generated"
unsafe_dir = out_dir / "unsafe_generated"

safe_dir.mkdir(parents=True, exist_ok=True)
unsafe_dir.mkdir(parents=True, exist_ok=True)

# prelude so clang can compile without kernel headers.
prelude = """\
#define SEC(NAME) __attribute__((section(NAME), used))

typedef unsigned long u64;
typedef unsigned int u32;
typedef unsigned short u16;
typedef unsigned char u8;

struct xdp_md {
    void *data;
    void *data_end;
};

static inline u32 bpf_get_prandom_u32(void) { return 0; }
static inline u64 bpf_ktime_get_ns(void) { return 0; }

#define XDP_ABORTED 0
#define XDP_PASS 2
#define XDP_DROP 1
"""

# list of safe bpf samples in .c format
safe_templates = [
    # bounds check before reading u32
    """SEC("xdp")
int prog(struct xdp_md *ctx) {{
    char *data = (char *)(ctx->data);
    char *data_end = (char *)(ctx->data_end);
    if (data + {size} > data_end) return XDP_PASS;
    u32 v = *(u32 *)(data + {offset});
    (void)v;
    return XDP_PASS;
}}
""",

    # loop with explicit bounded iterations and check
    """SEC("xdp")
int prog(struct xdp_md *ctx) {{
    char *data = (char *)(ctx->data);
    char *data_end = (char *)(ctx->data_end);
    u32 i;
    for (i = 0; i < {iters} && data + i + 1 <= data_end; i++) {{
        volatile u8 x = *(u8 *)(data + i);
        (void)x;
    }}
    return XDP_PASS;
}}
""",

    # check pointer before dereference
    """SEC("xdp")
int prog(struct xdp_md *ctx) {{
    char *data = (char*)(ctx->data);
    char *data_end = (char*)(ctx->data_end);
    if (data + {offset} >= data_end) return XDP_DROP;
    u8 b = *((u8 *) (data + {offset}));
    u32 idx = (u32)b % {mod};
    (void)idx;
    return XDP_PASS;
}}
""",

    # type cast and small arithmetic with check
    """SEC("xdp")
int prog(struct xdp_md *ctx) {{
    u32 rnd = bpf_get_prandom_u32();
    char *data = (char*)(ctx->data);
    char *data_end = (char*)(ctx->data_end);
    u32 off = rnd % {maxoff};
    if (data + off + 4 > data_end) return XDP_PASS;
    u32 v = *(u32 *)(data + off);
    (void)v;
    return XDP_PASS;
}}
"""]

# list of unsafe bpf samples in .c format (tricky edge cases)
unsafe_templates = [
    # read a u32 at a large offset without bounds check
    """SEC("xdp")
int prog(struct xdp_md *ctx) {{
    char *data = (char *)(ctx->data);
    /* NO bounds check - unsafe */
    u32 v = *(u32 *)(data + {offset});
    (void)v;
    return XDP_PASS;
}}
""",

    # pointer dereference without check using computed offset
    """SEC("xdp")
int prog(struct xdp_md *ctx) {{
    u32 rnd = bpf_get_prandom_u32();
    char *data = (char*)(ctx->data);
    /* Might point outside buffer */
    u32 idx = (rnd % {mod}) * {scale};
    u8 b = *(u8 *)(data + idx);
    (void)b;
    return XDP_PASS;
}}
""",

    # integer truncation leading to small index
    """SEC("xdp")
int prog(struct xdp_md *ctx) {{
    u32 big = bpf_get_prandom_u32();
    u8 small = (u8)big; /* truncation */
    char *data = (char*)(ctx->data);
    u8 val = *(u8 *)(data + small); /* no check */
    (void)val;
    return XDP_PASS;
}}
""",

    # uninitialized stack read
    """SEC("xdp")
int prog(struct xdp_md *ctx) {{
    u32 uninit;
    char *data = (char*)(ctx->data);
    /* use uninit without init */
    u32 idx = uninit % {mod};
    u8 v = *(u8 *)(data + idx); /* no check */
    (void)v;
    return XDP_PASS;
}}
""",

    # arithmetic underflow/overflow used as offset
    """SEC("xdp")
int prog(struct xdp_md *ctx) {{
    u32 len = bpf_get_prandom_u32();
    char *data = (char*)(ctx->data);
    u32 off = len - {sub}; /* could underflow */
    u8 v = *(u8 *)(data + off); /* no check */
    (void)v;
    return XDP_PASS;
}}
""",

    # tricky off-by-one access
    """SEC("xdp")
int prog(struct xdp_md *ctx) {{
    char *data = (char*)(ctx->data);
    char *data_end = (char*)(ctx->data_end);
    if (data + {size} >= data_end) return XDP_PASS; /* looks safe but fails at exact boundary */
    u32 v = *(u32 *)(data + {offset});
    (void)v;
    return XDP_PASS;
}}
""",

    # pointer arithmetic wraparound
    """SEC("xdp")
int prog(struct xdp_md *ctx) {{
    char *data = (char*)(ctx->data);
    u32 off = bpf_get_prandom_u32(); /* can wrap around on 32-bit arithmetic */
    u8 val = *(u8 *)(data + off); /* no check */
    (void)val;
    return XDP_PASS;
}}
""",

    # partially checked loop
    """SEC("xdp")
int prog(struct xdp_md *ctx) {{
    char *data = (char*)(ctx->data);
    char *data_end = (char*)(ctx->data_end);
    u32 i;
    for (i = 0; i < {iters}; i++) {{
        volatile u8 x = *(u8 *)(data + i); /* may go out of bounds */
        (void)x;
    }}
    return XDP_PASS;
}}
"""]

code_license = '\nchar _license[] SEC("license") = "GPL";\n'

# this function randomizes characteristics of the files to provide synthetic diversity to the dataset
def render_random(template, idx):
    return template.format(
        size=random.choice([4,8,16]),
        offset=random.choice([0,4,8,12,32,64,128]),
        iters=random.choice([1,2,4,8,16]),
        mod=random.choice([16,32,64,128,256]),
        maxoff=random.choice([32,64,128]),
        scale=random.choice([1,2,4]),
        sub=random.choice([1,2,16]),
        idx=idx)

# function to create the .c file
def make_file(path: Path, content: str):
    path.write_text(prelude + "\n" + content + "\n" + code_license)

# function to control the generation of samples
def generate_samples(n_safe=150, n_unsafe=150):
    # loop through and generate safe samples
    for i in range(1, n_safe + 1):
        tmpl = random.choice(safe_templates)
        content = render_random(tmpl, i)
        fname = safe_dir / f"safe_{i:03d}.c"
        make_file(fname, content)

    # loop through and generate unsafe samples
    for i in range(1, n_unsafe + 1):
        tmpl = random.choice(unsafe_templates)
        content = render_random(tmpl, i)
        fname = unsafe_dir / f"unsafe_{i:03d}.c"
        make_file(fname, content)

# Run the generator
generate_samples()

