import os
import re
import csv
from collections import Counter

# Directories
safe_dir = "../dataset/safe_disasm"
unsafe_dir = "../dataset/unsafe_disasm"
output_csv = "ebpf_features.csv"

# Regex for instruction and features
instr_re = re.compile(r"^\s*\d+:\s+([a-zA-Z0-9_.]+)")
call_re = re.compile(r"call\s+(\d+)")
stack_access_re = re.compile(r"\[r10-([0-9]+)\]")
jump_re = re.compile(r"\bj(a|eq|ne|lt|le|gt|ge|s|sg|sl)\b")


# Extract features from a single disasm file
def extract_features(file_path):
    with open(file_path, "r") as f:
        lines = f.readlines()

    instructions = []
    call_helpers = 0
    stack_accesses = 0
    jumps = 0
    backward_jumps = 0
    pointer_arith = 0
    invalid_ops = 0

    for line in lines:
        # Opcode extraction
        match = instr_re.search(line)
        if match:
            opcode = match.group(1)
            instructions.append(opcode)

        # Helper calls
        if call_re.search(line):
            call_helpers += 1

        # Stack access using frame pointer
        if stack_access_re.search(line):
            stack_accesses += 1

        # Jumps
        if jump_re.search(line):
            jumps += 1

        # Backward jump heuristic
        if "jmp" in line and "-" in line:
            backward_jumps += 1

        # Pointer arithmetic heuristic
        if any(x in line for x in ["r1 +", "r2 +", "r1 -", "r2 -", "ptr"]):
            pointer_arith += 1

        # Invalid operations
        if "invalid" in line.lower() or "unknown" in line.lower():
            invalid_ops += 1

    num_instr = len(instructions)
    unique_instr = len(set(instructions))

    # Opcode frequency dictionary
    opcode_freq = Counter(instructions)

    return {
        "instruction_count": num_instr,
        "unique_instructions": unique_instr,
        "avg_instr_length": (sum(len(i) for i in instructions) / num_instr) if num_instr else 0,
        "helper_calls": call_helpers,
        "stack_accesses": stack_accesses,
        "jumps": jumps,
        "backward_jumps": backward_jumps,
        "pointer_arithmetic": pointer_arith,
        "invalid_opcodes": invalid_ops,
        "opcode_freq": opcode_freq}


# collect all opcodes from both dirs
def collect_global_opcodes():
    opcodes = set()

    for dirpath in [safe_dir, unsafe_dir]:
        for file in os.listdir(dirpath):
            if file.endswith(".disasm"):
                fpath = os.path.join(dirpath, file)
                feats = extract_features(fpath)
                opcodes.update(feats["opcode_freq"].keys())

    return sorted(opcodes)


# extract full feature rows
def process_directory(path, label, all_opcodes):
    rows = []

    for file in os.listdir(path):
        if not file.endswith(".disasm"):
            continue

        fpath = os.path.join(path, file)
        feats = extract_features(fpath)

        row = {
            "file": file,
            "class": label,
            "instruction_count": feats["instruction_count"],
            "unique_instructions": feats["unique_instructions"],
            "avg_instr_length": feats["avg_instr_length"],
            "helper_calls": feats["helper_calls"],
            "stack_accesses": feats["stack_accesses"],
            "jumps": feats["jumps"],
            "backward_jumps": feats["backward_jumps"],
            "pointer_arithmetic": feats["pointer_arithmetic"],
            "invalid_opcodes": feats["invalid_opcodes"]}

        # Add opcode frequencies (0 if missing)
        for opc in all_opcodes:
            row[f"opc_{opc}"] = feats["opcode_freq"].get(opc, 0)

        rows.append(row)

    return rows


### SCRIPT START ###

print("Collecting global opcode vocabulary...")
all_opcodes = collect_global_opcodes()

print("Extracting safe features...")
safe_rows = process_directory(safe_dir, 0, all_opcodes)

print("Extracting unsafe features...")
unsafe_rows = process_directory(unsafe_dir, 1, all_opcodes)

# headers
base_features = [
    "file",
    "class",
    "instruction_count",
    "unique_instructions",
    "avg_instr_length",
    "helper_calls",
    "stack_accesses",
    "jumps",
    "backward_jumps",
    "pointer_arithmetic",
    "invalid_opcodes"]

opcode_features = [f"opc_{opc}" for opc in all_opcodes]
fieldnames = base_features + opcode_features

# write CSV file
with open(output_csv, "w", newline="") as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    for row in safe_rows + unsafe_rows:
        writer.writerow(row)

