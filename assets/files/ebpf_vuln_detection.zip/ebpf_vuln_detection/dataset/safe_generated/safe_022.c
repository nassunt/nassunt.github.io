#define SEC(NAME) __attribute__((section(NAME), used))

typedef unsigned long u64;
typedef unsigned int u32;
typedef unsigned short u16;
typedef unsigned char u8;

struct xdp_md {
    void *data;
    void *data_end;
};

static inline u32 bpf_get_prandom_u32(void) { return 0; }
static inline u64 bpf_ktime_get_ns(void) { return 0; }

#define XDP_ABORTED 0
#define XDP_PASS 2
#define XDP_DROP 1

SEC("xdp")
int prog(struct xdp_md *ctx) {
    char *data = (char*)(ctx->data);
    char *data_end = (char*)(ctx->data_end);
    if (data + 128 >= data_end) return XDP_DROP;
    u8 b = *((u8 *) (data + 128));
    u32 idx = (u32)b % 32;
    (void)idx;
    return XDP_PASS;
}


char _license[] SEC("license") = "GPL";
